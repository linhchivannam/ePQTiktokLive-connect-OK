# Type Compilation for JavaScript-based environments

- `./build-node-compatible.sh` - Builds the types for this package
- `./build-types-only.sh` - Builds TypeScript type-only stubs
- `./build-web-compatible.sh` - Builds Web-compatible stubs for the Cloud WebSockets server
